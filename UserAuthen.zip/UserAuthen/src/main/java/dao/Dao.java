package dao;

import connection.HibernateUtil;
import entity.Register;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Dao {


    public Dao(SessionFactory sessionFactory) {

    }

    public void saveUser(Register user) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession())
        {
            transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
            session.close();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
//    public boolean validate(String email, String password) {
//
//        Transaction transaction = null;
//
//        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
//            transaction = session.beginTransaction();
//            Register user = (Register) session.createQuery("FROM UserRegister U WHERE U.email = :email").setParameter("email", email)
//                    .uniqueResult();
//
//            if (user != null && user.getPassword().equals(password)) {
//                return true;
//            }
//            transaction.commit();
//        } catch (Exception e) {
//            if (transaction != null) {
//                transaction.rollback();
//            }
//            e.printStackTrace();
//        }
//        return false;
//    }

    public String signInUser(String email, String password) {

        Transaction transaction = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
            // start a transaction
            transaction = session.beginTransaction();
            // get an RegisterUser object
            Register registerUser = (Register) session.createQuery("FROM Register U WHERE U.email = :email").setParameter("email", email)
                    .uniqueResult();
            System.out.println(registerUser.getFirstname());
            if (registerUser.getPassword().equals(password)) {
                return "Welcome "+registerUser.getFirstname();
            }
            // commit transaction
            transaction.commit();
            session.close();
 
        return "Invalid username and password";
    }}


