package servlet;

import connection.HibernateUtil;
import dao.Dao;
import entity.Register;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.entity.Register;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		String firstname=req.getParameter("firstname");
		String lastname=req.getParameter("lastname");
		String email=req.getParameter("email");
		String password=req.getParameter("Password");
		
		
		Register register=new Register(firstname,lastname,email,password);
		System.out.println(register);
		Dao dao = new Dao(HibernateUtil.getSessionFactory());
		dao.saveUser(register);
		resp.sendRedirect("Login.jsp");
	}
	
	

}
