package servlet;


import connection.HibernateUtil;
import dao.Dao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class SignInServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        System.out.println(email+" "+password);
        Dao registerDao = new Dao(HibernateUtil.getSessionFactory());
        String f = registerDao.signInUser(email,password);
        System.out.println(f);
        HttpSession session = req.getSession();
        if(f!=null){
            session.setAttribute("msg",f+"");
            System.out.println("User login successfully (like) ");
        }else {
            session.setAttribute("msg","");
            System.out.println("something went wrong (no) ");
        }
        resp.sendRedirect("index.jsp");
    }
}
